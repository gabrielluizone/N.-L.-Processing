# PYTHON - PLN LISTA DE EXERCÍCIOS 1

# 1. Crie três variáveis e atribua os valores a seguir: a=1, b=5.9 e c=‘teste’. A partir disso, retorne o tipo de cada uma das variáveis. 
a = 1
b = 5.9
c = 'teste'

# --- #

# 2. Troque o valor da variável a por ‘1’ e verifique se o tipo da variável mudou. 
a = '1'
print(type(a))

# --- #

# 3. Faça a soma da variável b com a variável c. Interprete a saída, tanto em caso de execução correta quanto em caso de execução com erro. 
# print(b + c)
# O programa retorna um erro, pois a soma de string com valores númericos é impossível

# --- #

# 4. Crie uma lista com números de 0 a 9 (em qualquer ordem). Com ela, faça: 
lista = []
for i in range(0,10):
    lista.append(i)

# 4.a. Adicione o número 6 
lista.append(6)

# 4.b. nsira o número 7 na 3ª posição da lista 
lista.insert(2, 7)

# 4.c. Remova o elemento 3 da lista
lista.pop(2)

# 4.d. Adicione o número 4 
lista.append(4)

# 4.e. Verifique o número de ocorrências do número 4 na lista 
if 4 in lista:
    print('Número 4 está na lista!')

# --- #
    
# 5. Ainda com a lista criada na questão anterior, faça:
    
# 5.a. Retorne os primeiros 3 elementos da lista
print(lista[0:3])

# 5.b. Retorne os elementos que estão da 3ª posição até a 7ª posição da lista
print(lista[2:7])

# 5.c. Retorne os elementos da lista de 3 em 3 elementos
print(lista[::3])

# 5.d. Retorne os 3 últimos elementos da lista
print(lista[-3:])

# 5.e. Retorne todos os elementos menos os 4 últimos da lista
print(lista[:-4])

# --- #

# 6. Com a lista das questões anteriores, retorne o 6º elemento da lista.
print(lista[5])

# --- #

# 7. Altere o valor do 7º elemento da lista para o valor 12.
lista[6] = 12

# --- #

# 8. Inverta a ordem dos elementos na lista.
lista.reverse()

# --- #

# 9. Ordene a lista.
lista.sort()

# --- #

# 10. Crie uma tupla com números de 0 a 9 (em qualquer ordem) e tente:
tupla = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

# 10.a. Alterar o valor do 3º elemento da tupla para o valor 10
lista_temporaria = list(tupla)
lista_temporaria[2] = 10
tupla = tuple(lista_temporaria)

# 10.b. Verificar o índice (posição) do valor 5 na tupla
print(tupla.index(5))

# --- #

# 11. Crie um dicionário com 5 entradas e suas respectivas chaves e valores. Faça:
dicionario = {}
for i in range(0, 5):
    dicionario[i] = str(i + 10)

# 11.a. Imprima todas as chaves do dicionário
print("Chaves do dicionário:")
for chave in dicionario.keys():
    print(chave)

# 11.b. Imprima todos os valores do dicionário
print("\nValores do dicionário:")
for valor in dicionario.values():
    print(valor)

# 11.c. Imprima todos os itens do dicionário
print("\nItens do dicionário:")
for chave, valor in dicionario.items():
    print(chave, valor)

# 11.d. Imprima o 2º item do dicionário
print("\nSegundo item do dicionário:")
print(list(dicionario.items())[1])

# 11.e. Imprima o dicionário completo
print("\nDicionário completo:")
print(dicionario)

# 11.f. Percorra o dicionário, imprimindo para cada entrada o modelo "(chave) tem como valor (valor)"
print("\nPercorrendo o dicionário:")
for chave, valor in dicionario.items():
    print(f"{chave} tem como valor {valor}")

# --- #

# 12. Crie um arquivo e:

# 12.a. Escreva nele os números de 1 a 10
with open("numeros.txt", "w") as arquivo:
    for i in range(1, 11):
        arquivo.write(str(i) + "\n")

# 12.b. Depois de escrito, imprima na tela todos os números do arquivo
print("\nNúmeros do arquivo:")
with open("numeros.txt", "r") as arquivo:
    print(arquivo.read())

# 12.c. Escreva no arquivo os números de 11 a 20, substituindo os números que estavam antes no arquivo
with open("numeros.txt", "w") as arquivo:
    for i in range(11, 21):
        arquivo.write(str(i) + "\n")

# 12.d. Escreva no arquivo os números de 21 a 30, adicionando os números no final do arquivo (sem apagar o que já estavam lá)
with open("numeros.txt", "a") as arquivo:
    for i in range(21, 31):
        arquivo.write(str(i) + "\n")

# 12.e. Imprima na tela todos os números do arquivo novamente (de 11 a 30)
print("\nNúmeros do arquivo de 11 a 30:")
with open("numeros.txt", "r") as arquivo:
    print(arquivo.read())

# 12.f. Imprima na tela todos os números do arquivo novamente, mas agora linha por linha
print("\nNúmeros do arquivo, linha por linha:")
with open("numeros.txt", "r") as arquivo:
    for linha in arquivo:
        print(linha.strip())

