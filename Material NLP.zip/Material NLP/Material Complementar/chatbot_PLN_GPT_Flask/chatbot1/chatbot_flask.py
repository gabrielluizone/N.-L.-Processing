# pip install openai flask 

from flask import Flask, render_template, request
import openai

app = Flask(__name__)
openai.api_key = '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'

def pergunte_ao_chatbot(prompt, 
                        #engine='davinci'
                        engine='davinci-instruct-beta-v3'
                        ):
    response = openai.Completion.create(
      engine=engine,
      prompt=prompt,
      #temperature=0.7,
      #max_tokens=100,
      temperature=0.8,
      max_tokens=200,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0
    )
    return response.choices[0].text.strip()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get')
def get_bot_response():
    user_text = request.args.get('msg')
    if user_text.lower() in ['exit', 'parar', 'sair']:
        return "Chatbot GPT-3.5: Até logo!"
    else:
        bot_response = pergunte_ao_chatbot(user_text)
        return str(bot_response)

if __name__ == '__main__':
    app.run(debug=True)
