# pip install openai==0.18.1
# pip install config

import openai
import config

#openai.api_key = config.OPENAI_API_KEY if 'OPENAI_API_KEY' in dir(config) else ''
openai.api_key = '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'
print(f'openai.api_key : {openai.api_key}')


def openAIQuery(query):
    response = openai.Completion.create(
      engine="davinci-instruct-beta-v3",
      prompt=query,
      temperature=0.8,
      max_tokens=200,
      top_p=1,
      frequency_penalty=0,
      presence_penalty=0)

    if 'choices' in response:
        if len(response['choices']) > 0:
            answer = response['choices'][0]['text']
        else:
            answer = 'Opps sorry, you beat the AI this time'
    else:
        answer = 'Opps sorry, you beat the AI this time'

    return answer


if __name__ == '__main__':
    if not openai.api_key:
        print(f'api_key is not set')
        exit(0)
        
    query = 'Qual a temperatura na cidade de São Vicente?'
    try:
        response = openAIQuery(query)
        print(f'Response : {response}')
    except Exception as e:
        print(f'Exception : {str(e)}')
